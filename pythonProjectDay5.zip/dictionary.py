#dictionary - unordered collection of data, store values like map

#declaration
d = {"name":"sugumar","course":"bootcamp"}  #[->list
print(d)

d = dict(name="sugumar",course="bootcamp")  #list
print(d)

#key is immutable and value is mutable/immutable

d["name"]="sugumar v"
d["course"] = "bootcamp course"
d["duration"] = "day 5"
print(d)

#dictionary providex hashing
book_dict = {"python":"page3","django":"page4","flask":"page5"}

#adding and updating elements
book_dict["cherrypy"] = "page6"
book_dict["flask"] = "page7"
#book_dict.update({8`"flask":"page7","cherrpy":"page6"})
print(book_dict)

book_dict.update({"django":"page8","robot":"page10"})
print(book_dict)

#accessing the dictionary
print(book_dict.get("django"))
print(book_dict["django"])

print(book_dict.get("graphql"))
print(book_dict.get("graphql","Not-available"))
# print(book_dict["graphql"]) #it will raise exception if the key doesn't exist

#removing elements
del book_dict["django"] #removes the specified key
print(book_dict)

book_dict.pop("flask") #removes the specified key
print(book_dict)

book_dict.popitem() #removes the last item
print(book_dict)

#operations
print(book_dict.values())
print(book_dict.keys())

dict2 = {"test":["test1","test2","test3"],
         "test":"test"}
print(dict2)
print(dict2.keys())
print(dict2.values())

dict3 = {("username","password"):("test","****")} #unchangeable
print(dict3)

# dict4 = {["username","password"]:["test","****"]} #mutable is unhashable (changeable)
# print(dict4)

dict5 = {"8932489":
    {
        ("username","password"):("uname","****"),
        "name":"sugumar",
        "age":30,
        "max-transaction-per-day":100
     }
}

print(dict5["8932489"])

dict8 = {"key1":"value1","key2":"value2"}
print(dict8.items())

# student_marks = {"sugumar":{"cs":98,"maths":100},
#                    "steve":{"cs":99,"science":95}}
##[("cs",98),("maths",100)]
#{<key>:<value>}
#<key> -> string, int, tuple ( unchangeable, immutable )
#<value> -> List, tuple, string, int, dict ( changeable or unchangeable, mutable or immutable)

# dict9 = {{"test"}:"Test"}
# print(dict9)