#decision-making - similarly like taking a decision based on the condition in real
#if, if else, nested if, if-else

#program to determine the eligibility to vote
# year = int(input("enter the year of birth: "))
# if 2022 - year > 18:
#     print("yes")
# elif 2022 - year > 15:
#     print("wait for 3 more years to vote")
# else:
#     print("no")

#nested if
# number = int(input("enter the number:"))
# if (number % 2) == 0:
#     if (number % 5) == 0:
#         print("Number is divisible by both 2 and 5")
#     else:
#         print("Number is divisble by 2 alone")
# else:
#     print("Number is not divisble by neither 2 nor 5")

# if (number%2) == 0 and (number%5)==0:
#     print("Number is divisible by both 2 and 5")
# elif (number%5 == 0):
#     print("Number is divisible by 5")
# elif (number%2 == 0):
#     print("Number is divisible by 2")
# else:
#     print("Number is not divisble by neither 2 nor 5")

#loop statements
#while loop and while-else

#program to print all odd numbers
# i = 1
# while True:
#     print(i)
#     i = i+2
#program to print sum of the numbers in the list
l = [1,2,3,4,5,6,7,8,9,10] #0,....n #l[0], 0-9 < 10
# i = 0
# sum = 0
# n = len(l)-1
# while i <= n:  #0 < 10, 1 < 10, .... 9 < 10, 10<10 -False
#     sum = sum + l[i]
#     i = i+1
# else:
#     print(f"{i} reached the end - {n} of the list")
#     print(sum)

#range function -  start, stop, step - return the numbers within the range
#inclusive of start, exclusive of stop
# s  = range(0,10)
# print(list(s))

#for loop
l = [1,2,3,4,5,6,7,8,9,10]
sum = 0
for _ in range(0,len(l)):
    sum = sum + l[_]
print(sum)

sum = 0
for a8 in l:
    sum = sum + a8 #+= is same  = +
print(sum)

#tasks
#l = [89,21,234,82394,2782,9201,24584]
# i belongs to l is always > 0
# print the count of numbers which is divisible by 2
# count
# increement the loop when the condition is divisible by 2
# get the 2nd max element

#for loop works like below
# for each item in sequence
# if next item exist, it will execute statements of the loop
# if it reaches last, it will stop execute
#range

#1st iteration
# i=0, sum=1, i=1   #1
# i=1, sum=1+2, i=2  #2
# i=2, sum=1+2+3, i=3 #3
# i=3, sum=1+2+3, i=3  #4
# i=4, sum=1+2+3+4, i=5 #5
# i=9, sum = 1+2+3...+10, i=10